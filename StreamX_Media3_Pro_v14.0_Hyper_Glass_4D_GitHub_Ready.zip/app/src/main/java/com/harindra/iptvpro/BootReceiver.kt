package com.harindra.iptvpro

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.util.Log

class BootReceiver : BroadcastReceiver() {
    companion object {
        @Volatile
        private var lastBootLaunchElapsedMs: Long = 0L
        private const val MIN_BOOT_LAUNCH_INTERVAL_MS = 15_000L
    }

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != "android.intent.action.QUICKBOOT_POWERON") {
            return
        }

        try {
            val prefs = context.getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)
            val autoBootEnabled = prefs.getBoolean("auto_boot_enabled", true)
            if (!autoBootEnabled) {
                Log.i("StreamX", "BootReceiver: Auto-Boot is disabled by user setting; skipping launch.")
                return
            }

            val now = SystemClock.elapsedRealtime()
            if (lastBootLaunchElapsedMs > 0L && (now - lastBootLaunchElapsedMs) < MIN_BOOT_LAUNCH_INTERVAL_MS) {
                Log.i("StreamX", "BootReceiver: Duplicate boot broadcast ignored.")
                return
            }
            lastBootLaunchElapsedMs = now

            val launchIntent = Intent(context, PlayerActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
                )
                putExtra("from_boot_receiver", true)
            }
            context.startActivity(launchIntent)
        } catch (e: Exception) {
            Log.w("StreamX", "BootReceiver: Safe catch for background activity start restriction: ${e.message}")
        }
    }
}
