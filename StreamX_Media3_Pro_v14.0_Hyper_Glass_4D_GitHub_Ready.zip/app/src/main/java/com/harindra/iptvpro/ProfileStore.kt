package com.harindra.iptvpro

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

enum class ProfileType { M3U, XTREAM }

data class PlaylistProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: ProfileType,
    val source: String,
    val username: String = "",
    val password: String = ""
)

class ProfileStore(context: Context) {
    private val appContext = context.applicationContext
    private val fastMetaPrefs: SharedPreferences =
        appContext.getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)

    // Lazy initialization: Tink/KeyStore is NEVER loaded on cold boot if the user has no saved profiles
    private val securePrefs: SharedPreferences by lazy {
        try {
            EncryptedSharedPreferences.create(
                appContext,
                "streamx_secure_profiles",
                MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            Log.w("StreamX", "EncryptedSharedPreferences unavailable on this TV; using local fallback", e)
            appContext.getSharedPreferences("streamx_profiles_fallback", Context.MODE_PRIVATE)
        }
    }

    @Volatile
    private var cachedProfiles: MutableList<PlaylistProfile>? = null

    @Synchronized
    fun all(): MutableList<PlaylistProfile> {
        cachedProfiles?.let { return it.toMutableList() }
        // Fast-path skip of Tink KeyStore on cold boot if no profile has ever been saved
        if (!fastMetaPrefs.getBoolean("has_saved_profiles", true)) {
            val empty = mutableListOf<PlaylistProfile>()
            cachedProfiles = empty
            return mutableListOf()
        }
        val raw = try {
            securePrefs.getString("profiles", "[]") ?: "[]"
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to read saved profiles", e)
            "[]"
        }
        val parsed = try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                PlaylistProfile(
                    id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                    name = o.optString("name", "IPTV Account"),
                    type = runCatching { ProfileType.valueOf(o.optString("type", "M3U")) }.getOrDefault(ProfileType.M3U),
                    source = o.optString("source"),
                    username = o.optString("username"),
                    password = o.optString("password")
                )
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Corrupted profile JSON; resetting in-memory list", e)
            mutableListOf()
        }
        cachedProfiles = parsed
        fastMetaPrefs.edit().putBoolean("has_saved_profiles", parsed.isNotEmpty()).apply()
        return parsed.toMutableList()
    }

    @Synchronized
    fun save(profile: PlaylistProfile) {
        val list = all()
        val idx = list.indexOfFirst { it.id == profile.id }
        if (idx >= 0) list[idx] = profile else list.add(profile)
        persist(list)
    }

    @Synchronized
    fun delete(id: String) = persist(all().filterNot { it.id == id })

    fun activeId(): String? = try {
        fastMetaPrefs.getString("active_profile_id_fast", null)
            ?: if (fastMetaPrefs.getBoolean("has_saved_profiles", false)) securePrefs.getString("active_id", null) else null
    } catch (e: Exception) {
        Log.w("StreamX", "Failed to read active profile ID", e)
        null
    }

    fun setActive(id: String) {
        try {
            fastMetaPrefs.edit().putString("active_profile_id_fast", id).apply()
            if (fastMetaPrefs.getBoolean("has_saved_profiles", false)) {
                securePrefs.edit().putString("active_id", id).apply()
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to save active profile ID", e)
        }
    }

    // Upgrade 11: 4-Digit Parental PIN Lock & Per-Channel Audio Language Memory
    fun getParentalPin(): String = fastMetaPrefs.getString("parental_pin_code", "") ?: ""

    fun setParentalPin(pin: String) {
        fastMetaPrefs.edit().putString("parental_pin_code", pin.trim()).apply()
    }

    fun getLockedCategories(): Set<String> {
        return fastMetaPrefs.getStringSet("locked_categories", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleCategoryLock(category: String): Boolean {
        val norm = category.trim()
        val current = getLockedCategories().toMutableSet()
        val nowLocked = if (current.contains(norm)) {
            current.remove(norm)
            false
        } else {
            current.add(norm)
            true
        }
        fastMetaPrefs.edit().putStringSet("locked_categories", current).apply()
        return nowLocked
    }

    fun isCategoryLocked(category: String): Boolean {
        val pin = getParentalPin()
        if (pin.length != 4) return false
        val norm = category.trim()
        if (getLockedCategories().any { it.equals(norm, ignoreCase = true) }) return true
        val lower = norm.lowercase(Locale.ROOT)
        return lower.contains("adult") || lower.contains("18+") || lower.contains("xxx")
    }

    fun getPreferredAudioLanguage(channelId: String): String? {
        return fastMetaPrefs.getString("audio_lang_$channelId", null)?.takeIf { it.isNotBlank() }
    }

    fun setPreferredAudioLanguage(channelId: String, language: String) {
        fastMetaPrefs.edit().putString("audio_lang_$channelId", language.trim()).apply()
    }

    @Synchronized
    private fun persist(list: List<PlaylistProfile>) {
        cachedProfiles = list.toMutableList()
        fastMetaPrefs.edit().putBoolean("has_saved_profiles", list.isNotEmpty()).apply()
        try {
            val arr = JSONArray()
            list.forEach { p ->
                arr.put(
                    JSONObject()
                        .put("id", p.id)
                        .put("name", p.name)
                        .put("type", p.type.name)
                        .put("source", p.source)
                        .put("username", p.username)
                        .put("password", p.password)
                )
            }
            securePrefs.edit().putString("profiles", arr.toString()).apply()
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to persist profiles", e)
        }
    }
}
