package com.harindra.iptvpro

import android.content.Context
import android.util.Log
import android.util.LruCache
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Request
import java.util.Collections
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * v14.0 Direction-Aware Low-RAM Socket & DNS Pre-Warmer for 512MB RAM Android TVs.
 *
 * ZERO Disk / SQLite I/O during channel zapping:
 * Warms DNS + TCP + TLS + HTTP/2 sockets directly in RAM on NetworkClient.streamClient
 * so ExoPlayer connects to the real-time live edge in ~0ms.
 */
object StreamPreFetcher {
    private const val MIN_FREE_HEAP_FOR_PREFETCH = 14L * 1024L * 1024L // 14 MB safety floor

    private val prefetchScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var adjacentJob: Job? = null
    private var focusJob: Job? = null
    private val warmupInProgress = AtomicBoolean(false)

    // Lightweight in-memory LRU tracking recently warmed stream hosts/URLs (<64 KB RAM total)
    private val warmedSocketTimestamps = object : LruCache<String, Long>(64) {}
    private val activeWarmupSet = Collections.synchronizedSet(HashSet<String>(16))

    private fun hasSafeHeapForPrefetch(): Boolean {
        val rt = Runtime.getRuntime()
        val freeAndUnallocated = rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
        return freeAndUnallocated >= MIN_FREE_HEAP_FOR_PREFETCH
    }

    /**
     * Tier 1: Silently pre-warm adjacent channel connections sequentially in RAM,
     * prioritizing the user's active zapping direction first.
     */
    fun scheduleAdjacentPrefetch(
        @Suppress("UNUSED_PARAMETER") context: Context,
        nextUrl: String?,
        prevUrl: String?,
        preferForward: Boolean = true
    ) {
        adjacentJob?.cancel()
        adjacentJob = prefetchScope.launch {
            NetworkClient.prewarmHostDns(nextUrl)
            NetworkClient.prewarmHostDns(prevUrl)
            delay(180L) // Give the active stream priority for initial segment & decoder start.
            if (!isActive || !hasSafeHeapForPrefetch()) return@launch
            val primaryUrl = if (preferForward) nextUrl else prevUrl
            val secondaryUrl = if (preferForward) prevUrl else nextUrl
            if (!primaryUrl.isNullOrBlank()) {
                warmLiveConnectionInRam(primaryUrl)
            }
            delay(240L)
            if (!isActive || !hasSafeHeapForPrefetch()) return@launch
            if (!secondaryUrl.isNullOrBlank() && secondaryUrl != primaryUrl) {
                warmLiveConnectionInRam(secondaryUrl)
            }
        }
    }

    /**
     * Tier 2: When user highlights a channel in the drawer, pre-warm one socket in 75ms before OK is pressed.
     */
    fun scheduleFocusPrefetch(
        @Suppress("UNUSED_PARAMETER") context: Context,
        focusedUrl: String?
    ) {
        focusJob?.cancel()
        if (focusedUrl.isNullOrBlank()) return
        focusJob = prefetchScope.launch {
            NetworkClient.prewarmHostDns(focusedUrl)
            delay(75L) // Ultra-fast 75ms D-Pad focus pre-warm
            if (!isActive || !hasSafeHeapForPrefetch()) return@launch
            warmLiveConnectionInRam(focusedUrl)
        }
    }

    private fun warmLiveConnectionInRam(streamUrl: String) {
        if (!streamUrl.startsWith("http://", true) && !streamUrl.startsWith("https://", true)) return
        val now = System.currentTimeMillis()
        val lastWarmed = synchronized(warmedSocketTimestamps) { warmedSocketTimestamps.get(streamUrl) }
        if (lastWarmed != null && (now - lastWarmed) < 25_000L) {
            return // Connection already warm in OkHttp ConnectionPool
        }
        if (!activeWarmupSet.add(streamUrl)) return
        if (!warmupInProgress.compareAndSet(false, true)) {
            activeWarmupSet.remove(streamUrl)
            return
        }
        var warmedSuccessfully = false
        try {
            val req = Request.Builder()
                .url(streamUrl)
                .header("User-Agent", "StreamX-Media3Pro/14.0-HyperGlass (AndroidTV)")
                .header("Range", "bytes=0-127")
                .get()
                .build()
            val call = NetworkClient.streamClient.newCall(req)
            call.timeout().timeout(1800L, TimeUnit.MILLISECONDS)
            call.execute().use { res ->
                if (res.isSuccessful) {
                    res.body?.byteStream()?.use { stream ->
                        val buf = ByteArray(128)
                        stream.read(buf)
                    }
                    warmedSuccessfully = true
                }
            }
            if (warmedSuccessfully) {
                synchronized(warmedSocketTimestamps) {
                    warmedSocketTimestamps.put(streamUrl, System.currentTimeMillis())
                }
            }
        } catch (e: Exception) {
            Log.d("StreamX", "RAM socket warm skipped: ${e.message}")
        } finally {
            activeWarmupSet.remove(streamUrl)
            warmupInProgress.set(false)
        }
    }

    fun cancelAllPrefetches() {
        adjacentJob?.cancel()
        focusJob?.cancel()
    }

    fun trimIdleCacheOnLowMemory() {
        cancelAllPrefetches()
        synchronized(warmedSocketTimestamps) {
            warmedSocketTimestamps.evictAll()
        }
    }

    fun cacheUsedBytes(): Long {
        return synchronized(warmedSocketTimestamps) {
            warmedSocketTimestamps.size() * 1024L
        }
    }
}
